import { Router } from "express";
import { Database } from "../db.js";

const productsRouter = Router();

productsRouter.get("/", async (req, res) => {
  const db = new Database();
  const products = await db.query("SELECT * FROM products");
  res.json(products);
});

productsRouter.get("/:id", async (req, res) => {
  const db = new Database();
  const product = await db.query(`
      SELECT *
      FROM products
      WHERE id = ${req.params.id}
  `);
  res.json(product);
});

export default productsRouter;
