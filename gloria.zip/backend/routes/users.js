import { Router } from "express";
import { Database } from "../db.js";

const usersRouter = Router();

usersRouter.get("/:uid/orders", async (req, res) => {
  const db = new Database();
  const { uid } = req.params;

  //language=MySQL
  const orders = await db.query(
    `SELECT *
         FROM orders
                  JOIN order_items ON orders.id = order_items.order_id
                  JOIN products ON order_items.product_id = products.id
         WHERE orders.user_id = ${uid}`
  );

  const order = orders.reduce((acc, order) => {
    const { id, name, price, quantity } = order;
    acc[order.order_id] = acc[order.order_id] ?? {
      id: order.order_id,
      table_no: order.table_no,
      products: [],
    };
    acc[order.order_id].products.push({ id, name, price, quantity });
    return acc;
  }, {});

  res.json(Object.values(order).sort((a, b) => b.id - a.id));
});

export default usersRouter;
