import { Router } from "express";

import { Database } from "../db.js";

const ordersRouter = Router();

ordersRouter.get("/", async (req, res) => {
  const db = new Database();

  //language=MySQL
  const orders = await db.query(
    `SELECT *
         FROM orders
                  JOIN order_items ON orders.id = order_items.order_id
                  JOIN products ON order_items.product_id = products.id`
  );

  const order = orders.reduce((acc, order) => {
    const { id, name, price, quantity } = order;
    acc[order.order_id] = acc[order.order_id] ?? {
      id: order.order_id,
      user_id: order.user_id,
      table_no: order.table_no,
      products: [],
    };
    acc[order.order_id].products.push({ id, name, price, quantity });
    return acc;
  }, {});

  res.json(Object.values(order).sort((a, b) => b.id - a.id));
});

ordersRouter.post("/", async (req, res) => {
  const db = new Database();

  const { table_no, products } = req.body;
  const user_id = req.body.user_id ?? 1;

  const result = await db.query(
    `INSERT INTO orders (user_id, table_no)
         VALUES (${user_id}, ${table_no})`
  );

  const orderId = result.insertId;

  const orderItems = products
    .map((product) => `(${orderId}, ${product.id}, ${product.quantity})`)
    .join(",");

  await db.query(
    `INSERT INTO order_items (order_id, product_id, quantity)
         VALUES ${orderItems}`
  );

  res.json(result);
});

export default ordersRouter;
