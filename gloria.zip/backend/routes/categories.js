import { Router } from "express";
import { Database } from "../db.js";

const categoriesRouter = Router();

categoriesRouter.get("/", async (req, res) => {
  const db = new Database();
  const categories = await db.query("SELECT * FROM categories");
  res.json(categories);
});

categoriesRouter.get("/:id/products", async (req, res) => {
  const db = new Database();
  const products = await db.query(
    `SELECT id, name, price, description
         FROM products
         WHERE category_id = ${req.params.id}`
  );
  res.json(products);
});

export default categoriesRouter;
