import mysql from "mysql2";

export class Database {
  static #connection = null;

  constructor() {
    if (!Database.#connection) Database.#connect();
  }

  static #connect() {
    // init db
    const connection = mysql.createConnection({
      host: "localhost",
      port: "3306",
      user: "root",
      password: "password",
      database: "gloria",
    });

    connection.connect();
    this.#connection = connection;
  }

  async query(sql) {
    return new Promise((resolve, reject) => {
      Database.#connection.query(sql, (err, result) => {
        if (err) reject(err);
        resolve(result);
      });
    });
  }

  close() {
    Database.#connection.end();
  }
}
