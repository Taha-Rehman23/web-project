export default [
  {
    id: 1,
    name: "Hot Coffee",
  },
  {
    id: 2,
    name: "Cold Coffee",
  },
  {
    id: 3,
    name: "Hot Tea",
  },
  {
    id: 4,
    name: "Cold Tea",
  },
  {
    id: 5,
    name: "Hot Chocolate",
  },
];
