export default [
  {
    id: 1,
    name: "Guest",
    email: "guest@gmail.com",
    password: "123456",
  },
  {
    id: 2,
    name: "John",
    email: "john@gmail.com",
    password: "123456",
  },
];
