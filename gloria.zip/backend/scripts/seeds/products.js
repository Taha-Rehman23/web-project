export default [
  {
    id: 1,
    category_id: 1,
    name: "Cappuccino",
    price: 399,
    description:
      "A cappuccino is an espresso-based coffee drink that originated in Italy, and is traditionally prepared with steamed milk foam.",
  },
  {
    id: 2,
    category_id: 1,
    name: "Latte",
    price: 499,
    description:
      "A latte is a coffee drink made with espresso and steamed milk.",
  },
  {
    id: 3,
    category_id: 1,
    name: "Americano",
    price: 599,
    description:
      "Caffè Americano or Americano is a type of coffee drink prepared by diluting an espresso with hot water, giving it a similar strength to, but different flavor from, traditionally brewed coffee.",
  },
  {
    id: 4,
    category_id: 1,
    name: "Espresso",
    price: 699,
    description:
      "Espresso is coffee brewed by forcing a small amount of nearly boiling water under pressure through finely ground coffee beans.",
  },
  {
    id: 5,
    category_id: 1,
    name: "Mocha",
    price: 799,
    description:
      "A caffè mocha, also called mocaccino, is a chocolate-flavored variant of a caffè latte.",
  },
  {
    id: 6,
    category_id: 1,
    name: "Macchiato",
    price: 899,
    description:
      "Caffè macchiato, sometimes called espresso macchiato, is an espresso coffee drink with a small amount of milk, usually foamed.",
  },

  {
    id: 7,
    category_id: 2,
    name: "Iced Coffee",
    price: 399,
    description:
      "Iced coffee is a type of coffee beverage served chilled, brewed variously with the fundamental division being cold brew – brewing the coffee cold, yielding a different flavor, and not requiring cooling – or brewing normally and then cooling, generally by simply pouring over ice or into ice cold milk.",
  },
  {
    id: 8,
    category_id: 2,
    name: "Iced Latte",
    price: 499,
    description: "Iced latte is espresso and cold milk poured over ice.",
  },
  {
    id: 9,
    category_id: 2,
    name: "Iced Americano",
    price: 599,
    description:
      "Iced Americano is a type of coffee drink prepared by diluting an espresso with cold water, giving it a similar strength to, but different flavor from, traditionally brewed coffee.",
  },
  {
    id: 10,
    category_id: 2,
    name: "Iced Espresso",
    price: 699,
    description: "Iced espresso is espresso coffee served over ice.",
  },
  {
    id: 11,
    category_id: 2,
    name: "Iced Mocha",
    price: 799,
    description: "Iced mocha is a chocolate-flavored variant of a caffè latte.",
  },
  {
    id: 12,
    category_id: 2,
    name: "Iced Macchiato",
    price: 899,
    description:
      "Iced macchiato is an espresso coffee drink with a small amount of milk, usually foamed, served over ice.",
  },
  {
    id: 13,
    category_id: 3,
    name: "Green Tea",
    price: 399,
    description:
      "Green tea is a type of tea that is made from Camellia sinensis leaves that have not undergone the same withering and oxidation process used to make oolong teas and black teas.",
  },
  {
    id: 14,
    category_id: 3,
    name: "Black Tea",
    price: 499,
    description:
      "Black tea is a type of tea that is more oxidized than oolong, green and white teas.",
  },
  {
    id: 15,
    category_id: 3,
    name: "Oolong Tea",
    price: 599,
    description:
      "Oolong is a traditional Chinese tea produced through a process including withering the plant under strong sun and oxidation before curling and twisting.",
  },
  {
    id: 16,
    category_id: 3,
    name: "White Tea",
    price: 699,
    description:
      "White tea may refer to one of several styles of tea which generally feature young or minimally processed leaves of the Camellia sinensis plant.",
  },
  {
    id: 17,
    category_id: 3,
    name: "Herbal Tea",
    price: 799,
    description:
      "Herbal teas—less commonly called tisanes are beverages made from the infusion or decoction of herbs, spices, or other plant material in hot water.",
  },
  {
    id: 18,
    category_id: 3,
    name: "Chai Tea",
    price: 899,
    description:
      "Masala chai is a flavoured tea beverage made by brewing black tea with a mixture of aromatic Indian spices and herbs.",
  },

  {
    id: 19,
    category_id: 4,
    name: "Iced Green Tea",
    price: 399,
    description:
      "Iced green tea is a type of tea that is made from Camellia sinensis leaves that have not undergone the same withering and oxidation process used to make oolong teas and black teas.",
  },
  {
    id: 20,
    category_id: 4,
    name: "Iced Black Tea",
    price: 499,
    description:
      "Iced black tea is a type of tea that is more oxidized than oolong, green and white teas.",
  },
  {
    id: 21,
    category_id: 4,
    name: "Iced Oolong Tea",
    price: 599,
    description:
      "Iced oolong is a traditional Chinese tea produced through a process including withering the plant under strong sun and oxidation before curling and twisting.",
  },
  {
    id: 22,
    category_id: 4,
    name: "Iced White Tea",
    price: 699,
    description:
      "Iced white tea may refer to one of several styles of tea which generally feature young or minimally processed leaves of the Camellia sinensis plant.",
  },
  {
    id: 23,
    category_id: 4,
    name: "Iced Herbal Tea",
    price: 799,
    description:
      "Iced herbal teas—less commonly called tisanes are beverages made from the infusion or decoction of herbs, spices, or other plant material in hot water.",
  },
  {
    id: 24,
    category_id: 4,
    name: "Iced Chai Tea",
    price: 899,
    description:
      "Iced masala chai is a flavoured tea beverage made by brewing black tea with a mixture of aromatic Indian spices and herbs.",
  },

  {
    id: 25,
    category_id: 5,
    name: "Hot Chocolate",
    price: 399,
    description:
      "Hot chocolate, also known as drinking chocolate, cocoa, and as chocolate tea in Nigeria, is a heated drink consisting of shaved chocolate, melted chocolate or cocoa powder, heated milk or water, and usually a sweetener.",
  },
  {
    id: 26,
    category_id: 5,
    name: "White Hot Chocolate",
    price: 499,
    description:
      "White hot chocolate is a hot chocolate beverage that is white in color rather than brown.",
  },
  {
    id: 27,
    category_id: 5,
    name: "Dark Hot Chocolate",
    price: 599,
    description:
      "Dark hot chocolate is a hot chocolate beverage that is dark in color rather than brown.",
  },
  {
    id: 28,
    category_id: 5,
    name: "Milk Hot Chocolate",
    price: 699,
    description:
      "Milk hot chocolate is a hot chocolate beverage that is milk in color rather than brown.",
  },
  {
    id: 29,
    category_id: 5,
    name: "Caramel Hot Chocolate",
    price: 799,
    description:
      "Caramel hot chocolate is a hot chocolate beverage that is caramel in color rather than brown.",
  },
  {
    id: 30,
    category_id: 5,
    name: "Mocha Hot Chocolate",
    price: 899,
    description:
      "Mocha hot chocolate is a hot chocolate beverage that is mocha in color rather than brown.",
  },
  {
    id: 31,
    category_id: 5,
    name: "Hazelnut Hot Chocolate",
    price: 999,
    description:
      "Hazelnut hot chocolate is a hot chocolate beverage that is hazelnut in color rather than brown.",
  },
];
