export default [
  {
    id: 1,
    user_id: 1,
    table_no: 1,
    items: [
      {
        product_id: 1,
        quantity: 1,
      },
      {
        product_id: 2,
        quantity: 1,
      },
    ],
  },
  {
    id: 2,
    table_no: 2,
    items: [
      {
        product_id: 5,
        quantity: 2,
      },
      {
        product_id: 12,
        quantity: 8,
      },
      {
        product_id: 24,
        quantity: 2,
      },
    ],
  },
];
