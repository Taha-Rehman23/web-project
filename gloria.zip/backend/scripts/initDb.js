import { Database } from "../db.js";
import productsData from "./seeds/products.js";
import categoriesData from "./seeds/categories.js";
import ordersData from "./seeds/orders.js";
import usersData from "./seeds/users.js";

// create tables if not exists
const createTables = async (db) => {
  // language=MySQL
  await db.query(`
        CREATE TABLE IF NOT EXISTS users
        (
            id       INT AUTO_INCREMENT PRIMARY KEY,
            email    VARCHAR(255) NOT NULL,
            password VARCHAR(255) NOT NULL
        );
    `);

  // language=MySQL
  await db.query(`
        CREATE TABLE IF NOT EXISTS categories
        (
            id   INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL
        );
    `);

  // language=MySQL
  await db.query(`
        CREATE TABLE IF NOT EXISTS products
        (
            id          INT AUTO_INCREMENT PRIMARY KEY,
            category_id INT          NOT NULL,
            name        VARCHAR(255) NOT NULL,
            description TEXT,
            price       INT          NOT NULL
        );
    `);

  // language=MySQL
  await db.query(`
      CREATE TABLE IF NOT EXISTS orders
      (
          id      INT AUTO_INCREMENT PRIMARY KEY,
          user_id INT default 1,
          table_no   INT NOT NULL
      );
  `);

  // language=MySQL
  await db.query(`
        CREATE TABLE IF NOT EXISTS order_items
        (
            id         INT AUTO_INCREMENT PRIMARY KEY,
            order_id   INT NOT NULL,
            product_id INT NOT NULL,
            quantity   INT NOT NULL
        );
    `);
};

const seed = async (db) => {
  // seed categories
  const categoryValues = categoriesData
    .map((category) => `(${category.id}, '${category.name}')`)
    .join(", ");

  // language=MySQL
  await db.query(`
        INSERT INTO categories (id, name)
        VALUES ${categoryValues}
    `);

  // seed products
  const productValues = productsData
    .map(
      (product) =>
        `(${product.id}, ${product.category_id}, '${product.name}', '${product.description}', ${product.price})`
    )
    .join(", ");

  // language=MySQL
  await db.query(`
        INSERT INTO products (id, category_id, name, description, price)
        VALUES ${productValues}
    `);

  // seed users
  const userValues = usersData
    .map((user) => `(${user.id}, '${user.email}', '${user.password}')`)
    .join(", ");

  // language=MySQL
  await db.query(`
        INSERT INTO users (id, email, password)
        VALUES ${userValues}
    `);

  // seed orders and order items
  const orderValues = ordersData
    .map(
      (order) => `(${order.id}, ${order.user_id ?? "NULL"}, ${order.table_no})`
    )
    .join(", ");

  const orderItemValues = ordersData
    .map((order) =>
      order.items.map(
        (item) => `(${order.id}, ${item.product_id}, ${item.quantity})`
      )
    )
    .flat()
    .join(", ");

  // language=MySQL
  await db.query(`
      INSERT INTO orders (id, user_id, table_no)
      VALUES ${orderValues}
  `);

  // language=MySQL
  await db.query(`
      INSERT INTO order_items (order_id, product_id, quantity)
      VALUES ${orderItemValues}
  `);
};

const db = new Database();

// drop tables if exists
await db.query(`DROP TABLE IF EXISTS order_items;`);
await db.query(`DROP TABLE IF EXISTS orders;`);
await db.query(`DROP TABLE IF EXISTS products;`);
await db.query(`DROP TABLE IF EXISTS categories;`);
await db.query(`DROP TABLE IF EXISTS users;`);
console.log("Database reset");

await createTables(db);
console.log("Tables created");

await seed(db);
console.log("Tables seeded");

db.close();
console.log("Done");
