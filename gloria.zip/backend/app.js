import express from "express";
import logger from "morgan";
import { createServer } from "http";
import cors from "cors";

import categoriesRouter from "./routes/categories.js";
import ordersRouter from "./routes/orders.js";
import usersRouter from "./routes/users.js";
import productsRouter from "./routes/products.js";

const app = express();
const port = 5000;

// setting up the express app
app.use(logger("dev"));
app.use(
  cors({
    origin: "*",
  })
);
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// importing the routes
app.use("/api/categories", categoriesRouter);
app.use("/api/products", productsRouter);
app.use("/api/orders", ordersRouter);
app.use("/api/users", usersRouter);

// Starting the node server
const server = createServer(app);
server.listen(port);

server.on("listening", () => {
  console.log(`Listening on port ${port}`);
});
