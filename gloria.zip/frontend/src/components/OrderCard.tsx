import {OrderDTO} from "../api/getOrders.ts";

export interface OrderCardProps {
  order: OrderDTO,
  showPrice?: boolean,
}

export default function OrderCard({order, showPrice}: OrderCardProps) {
  return (
    <div className="card bg-base-100 shadow-xl">
      <div className="card-body">
        <h1 className="card-title">Order #{order.id}</h1>
        <h2 className="card-subtitle mb-2 text-muted">Table #{order.table_no}</h2>
        <table className="table">
          <thead>
          <tr>
            <th>Name</th>
            {showPrice && <th>Unit Price</th>}
            <th>Quantity</th>
            {showPrice && <th>Price</th>}
          </tr>
          </thead>
          <tbody>
          {
            order.products.map(product => (
              <tr>
                <th>{product.name}</th>
                {showPrice && <td>{product.price}</td>}
                <td>{product.quantity}</td>
                {showPrice && <td>{product.price * product.quantity}</td>}
              </tr>
            ))
          }
          </tbody>
        </table>
        {
          showPrice &&
            <div className="mt-auto flex px-8 pt-4 justify-end items-center border-t border-base-300 gap-4">
                <span>Total Price:</span>
                <span className="text-2xl font-bold text-right">{
                  order.products.reduce((acc, product) => acc + product.price * product.quantity, 0)
                } Rs</span>
            </div>
        }
      </div>
    </div>
  );
}