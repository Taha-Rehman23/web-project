import {Category} from "../api/getCategories.ts";

export interface CategoryTabsProps {
  categories: Category[];
  activeCategory?: Category;
  onChooseCategory: (category: Category) => void;
}

export default function CategoryTabs(props: CategoryTabsProps) {
  return (
    <div className="tabs tabs-boxed inline-flex">
      {
        props.categories.map((category) => (
          <a className={`tab ${props.activeCategory === category ? "tab-active" : ""}`}
             onClick={() => props.onChooseCategory(category)}>{category.name}</a>
        ))
      }
    </div>
  );
}
