import {Link} from "react-router-dom";

export default function Navbar() {
  return (
    <div className="navbar sticky top-0 z-10 bg-base-100/60 backdrop-filter backdrop-blur-md border-b border-base-300">
      <div className="navbar-start">
        <Link to="/store">
          <a className="btn btn-ghost normal-case text-xl">Gloria Jeans</a>
        </Link>
      </div>
      <div className="navbar-center flex">
        <ul className="menu menu-horizontal px-1 gap-4">
          <li>
            <Link to="/store">
              Store
            </Link>
          </li>
          <li>
            <Link to="/orders">
              My Orders
            </Link>
          </li>
        </ul>
      </div>
      {/*<div className="navbar-end">*/}
      {/*  <Link to="/auth/login">*/}
      {/*    <a className="btn">Login / Signup</a>*/}
      {/*  </Link>*/}
      {/*</div>*/}
    </div>
  )
}