import {Product} from "../api/getProducts.ts";

interface ProductCardProps {
  product: Product;
  quantity: number;
  setQuantity: (quantity: number) => void;
}

export default function ProductCard({product, quantity, setQuantity}: ProductCardProps) {
  return (
    <div className="card bg-base-100 shadow-xl">
      <div className="card-body">
        <h2 className="card-title">{product.name}</h2>
        <p>{product.description}</p>
        <div className="flex justify-between">
          <div>
            <p>Price</p>
            <p className="text-2xl font-bold">{product.price} Rs</p>
          </div>
          <div>
            <p>Total Price</p>
            <p className="text-2xl font-bold">{product.price * quantity} Rs</p>
          </div>
        </div>
        <div className="card-actions justify-center">
          <div className="flex flex-col items-center form-control">
            <label className="label">Quantity</label>
            <div className="flex items-center gap-4">
              <button onClick={() => setQuantity(Math.max(0, quantity - 1))} className="btn btn-circle btn-sm">
                -
              </button>
              <input
                type="number"
                className="input input-bordered w-24"
                value={quantity}
                onChange={e => setQuantity(Math.max(0, parseInt(e.target.value)))}
              />
              <button onClick={() => setQuantity(quantity + 1)} className="btn btn-circle btn-sm">
                +
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}