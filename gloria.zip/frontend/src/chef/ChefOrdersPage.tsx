import {useEffect, useState} from "react";
import getOrders, {OrderDTO} from "../api/getOrders.ts";
import OrderCard from "../components/OrderCard.tsx";

export default function ChefOrdersPage() {
  const [orders, setOrders] = useState<OrderDTO[]>([]);

  useEffect(
    () => {
      getOrders()
        .then(orders => setOrders(orders))
    }, []);

  return (
    <div>
      <div className="container mx-auto py-8">
        <h1 className="text-4xl font-bold pb-4">Orders</h1>
        <div className="grid lg:grid-cols-2 gap-8">
          {
            orders.map(order => (
              <OrderCard order={order} key={order.id}/>
            ))
          }
        </div>
      </div>
    </div>
  );
}