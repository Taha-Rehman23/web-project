import Navbar from "../components/Navbar.tsx";
import CategoryTabs from "../components/CategoryTabs.tsx";
import {useEffect, useState} from "react";
import getCategories, {Category} from "../api/getCategories.ts";
import getProducts, {Product} from "../api/getProducts.ts";
import ProductCard from "../components/ProductCard.tsx";
import placeOrder from "../api/placeOrder.ts";

interface CartItem {
  product: Product;
  quantity: number;
}

export default function StorePage() {
  const tables = [1, 2, 3, 4, 5, 6, 7, 8, 9];

  const [selectedTable, setSelectedTable] = useState<number>(tables[0]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [activeCategory, setActiveCategory] = useState<Category | undefined>(undefined);

  const [loading, setLoading] = useState<boolean>(false);

  useEffect(() => {
    getCategories().then(cat => {
      setCategories(cat);
      if (cat.length > 0) setActiveCategory(cat[0]);
    });

    getProducts().then(prods => {
      setProducts(prods);
    });
  }, []);


  function handleAddToCart(prod: Product, quantity: number) {
    const item = cart.find(item => item.product.id === prod.id);

    if (item) {
      if (quantity === 0) {
        setCart(cart.filter(item => item.product.id !== prod.id));
        return;
      }
      item.quantity = quantity;
      setCart([...cart]);
    } else {
      if (quantity === 0) return;
      setCart([...cart, {product: prod, quantity}]);
    }
  }

  function handleCheckout() {
    setLoading(true);
    placeOrder({
      table_no: selectedTable,
      products: cart.map(item => ({
        id: item.product.id,
        quantity: item.quantity
      }))
    }).then(() => {
      setCart([]);
    }).finally(() => {
      setLoading(false);
    });
  }

  return (
    <div className="w-screen h-screen flex flex-col overflow-y-auto">
      <Navbar/>

      <div className="container mx-auto my-8 gap-8 grow flex flex-col">
        <div className="self-center">
          <CategoryTabs
            categories={categories}
            activeCategory={activeCategory}
            onChooseCategory={(cat) => setActiveCategory(cat)}/>
        </div>

        <div className="grid gap-8 lg:grid-cols-2 xl:grid-cols-3">
          {
            products.filter(prod => prod.category_id === activeCategory?.id).map((prod, i) => (
              <ProductCard
                key={i}
                product={prod}
                quantity={cart.find(item => item.product.id === prod.id)?.quantity || 0}
                setQuantity={(quantity) => handleAddToCart(prod, quantity)}/>
            ))
          }
        </div>
      </div>

      {/*footer*/}
      <div
        className="sticky bottom-0 bg-base-100 border-t border-base-300 flex items-center justify-end gap-4 py-3 px-8">
        <p>Table:</p>
        <select
          className="select select-bordered w-24"
          value={selectedTable}
          onChange={e => setSelectedTable(parseInt(e.target.value))}
        >
          {
            tables.map((table, i) => (
              <option key={i} value={table}>{table}</option>
            ))
          }
        </select>
        <p>Total Price:</p>
        <p className="text-2xl font-bold">{
          cart.reduce((acc, item) => acc + item.product.price * item.quantity, 0)
        } Rs</p>
        <button disabled={cart.length === 0 || loading} onClick={handleCheckout} className="btn btn-primary">
          {loading && <span className="loading loading-spinner"/>}
          Checkout
        </button>
      </div>
    </div>
  );
}
