import Navbar from "../components/Navbar.tsx";
import OrderCard from "../components/OrderCard.tsx";
import {OrderDTO} from "../api/getOrders.ts";
import {useEffect, useState} from "react";
import getMyOrders from "../api/getMyOrders.ts";

export default function MyOrdersPage() {
  const [orders, setOrders] = useState<OrderDTO[]>([]);

  useEffect(
    () => {
      getMyOrders().then(orders => setOrders(orders));
    },
    []
  );

  return (
    <div className="w-screen h-screen flex flex-col overflow-y-auto">
      <Navbar/>

      <div className="container mx-auto py-8">
        <h1 className="text-4xl font-bold pb-4">My Orders</h1>
        <div className="grid lg:grid-cols-2 gap-8">
          {
            orders.map(order => (
              <OrderCard showPrice order={order} key={order.id}/>
            ))
          }
        </div>
      </div>
    </div>
  );
}