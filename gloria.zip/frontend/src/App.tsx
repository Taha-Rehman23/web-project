import {BrowserRouter, Navigate, Route, Routes} from "react-router-dom";
import StorePage from "./store/StorePage.tsx";
import ChefOrdersPage from "./chef/ChefOrdersPage.tsx";
import AccountantOrdersPage from "./accountant/AccountantOrdersPage.tsx";
import MyOrdersPage from "./store/MyOrdersPage.tsx";

function App() {

  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route
            path="/store"
            element={
              <StorePage/>
            }
          />

          <Route
            path="/orders"
            element={
              <MyOrdersPage/>
            }
          />

          <Route path="/auth">
            <Route path="login"/>
            <Route path="signup"/>
          </Route>

          <Route path="/chef">
            <Route path="orders" element={
              <ChefOrdersPage/>
            }/>
          </Route>

          <Route path="/accountant">
            <Route path="orders" element={
              <AccountantOrdersPage/>
            }/>
          </Route>

          <Route path="*" element={<Navigate to="/store" replace={true}/>}/>
        </Routes>
      </BrowserRouter>
    </>
  )
}


export default App
