export interface Product {
  id: number;
  category_id: number;
  name: string;
  description: string;
  price: number;
}

export default async function getProducts() {
  const data = await fetch('http://localhost:5000/api/products').then(res => res.json());
  return data as Product[];
}
