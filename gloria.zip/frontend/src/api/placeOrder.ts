export interface PlaceOrderDTO {
  table_no: number;
  user_id?: number;
  products: {
    id: number;
    quantity: number;
  }[];
}

export default async function placeOrder(order: PlaceOrderDTO) {
  const data = await fetch('http://localhost:5000/api/orders', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(order)
  }).then(res => res.json());
  return data as PlaceOrderDTO;
}
