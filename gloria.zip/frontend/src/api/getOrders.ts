export interface OrderDTO {
  id: number;
  table_no: number;
  user_id?: number;
  products: {
    id: number;
    name: string;
    price: number;
    quantity: number;
  }[];
}

export default function getOrders() {
  return fetch('http://localhost:5000/api/orders')
    .then(res => res.json())
    .then(data => data as OrderDTO[]);
}
