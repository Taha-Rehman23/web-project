export interface Category {
  id: number;
  name: string;
}

export default async function getCategories() {
  const data = await fetch('http://localhost:5000/api/categories').then(res => res.json());
  return data as Category[];
}
