import {OrderDTO} from "./getOrders.ts";

export default function getMyOrders() {
  return fetch('http://localhost:5000/api/users/1/orders')
    .then(response => response.json())
    .then(data => data as OrderDTO[]);
}